export {POST} from '@genkit-ai/next';
